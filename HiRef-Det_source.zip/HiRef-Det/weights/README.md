Place the five downloaded .pt files in this directory. Their SHA-256 hashes are in ../provenance/weights_manifest.json.
