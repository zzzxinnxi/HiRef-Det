# Checkpoints

`manifest.json` lists all packaged checkpoint hashes, sizes and experiment roles. The five initial release files also remain at the GitHub repository root for compatibility; `python scripts/fetch_weights.py` places them under this directory. Run with `--all` for supplementary checkpoints when published.

Checkpoint files are copied byte for byte; learned tensors were not edited. Historical model class names are preserved. Load only trusted checkpoints: PyTorch .pt files can contain serialized Python objects.
