"""
LDCA: Lightweight Dynamic Context Aggregation for the P2 small-object branch.

Problem it targets:
  P2 features are high-resolution but semantically weak and noisy. Dense small
  objects need both preserved local detail AND mid-scale context, fused adaptively
  rather than blindly summed.

Structure (default 'gate' mode):
  align    : 1x1 Conv  (channel align c1 -> c2)
  detail   : DWConv3x3 + DWConv5x5 (parallel, summed)  -> 1x1 fuse
  context  : 3x parallel DWConv3x3 with dilation 1/2/3  -> concat -> 1x1 fuse
  gate     : spatial gate from avg+max pool of aligned feat -> sigmoid (B,1,H,W)
  fusion   : F = g * D + (1 - g) * C
  output   : y = identity + out_conv(F)   (residual)

Ablation modes (arg `mode`):
  'detail'  : only detail branch              -> y = identity + out_conv(D)
  'context' : only context branch             -> y = identity + out_conv(C)
  'sum'     : detail + context, no gate       -> y = identity + out_conv(D + C)
  'gate'    : dynamic gated fusion (default)  -> y = identity + out_conv(g*D+(1-g)*C)

Shape: B x C x H x W -> B x C x H x W (preserved). Use as a single-input module
in the neck after the P2 fusion block, before Detect.
"""

import torch
import torch.nn as nn
from ultralytics.nn.modules.conv import Conv, DWConv


class LDCA(nn.Module):
    def __init__(self, c1, c2=None, mode="gate", k_detail=(3, 5), dilations=(1, 2, 3)):
        super().__init__()
        c2 = c2 or c1
        self.mode = mode
        self.c1, self.c2 = c1, c2

        # 1) channel align
        self.align = Conv(c1, c2, 1, 1)

        # 2) detail branch (parallel depthwise, summed)
        if mode in ("detail", "sum", "gate"):
            self.detail_conv3 = DWConv(c2, c2, k_detail[0], 1)
            self.detail_conv5 = DWConv(c2, c2, k_detail[1], 1)
            self.detail_fuse = Conv(c2, c2, 1, 1)

        # 3) context branch (parallel dilated depthwise -> concat -> fuse)
        if mode in ("context", "sum", "gate"):
            self.context_d1 = DWConv(c2, c2, 3, 1, d=dilations[0])
            self.context_d2 = DWConv(c2, c2, 3, 1, d=dilations[1])
            self.context_d3 = DWConv(c2, c2, 3, 1, d=dilations[2])
            self.context_fuse = Conv(c2 * 3, c2, 1, 1)

        # 4) spatial gate (only needed for gated fusion)
        if mode == "gate":
            self.gate = nn.Sequential(
                nn.Conv2d(2, 1, 3, 1, 1, bias=True),
                nn.Sigmoid(),
            )

        # 5) output projection
        self.out_conv = Conv(c2, c2, 3, 1)

        # residual shortcut if channels differ
        self.shortcut = nn.Identity() if c1 == c2 else Conv(c1, c2, 1, 1, act=False)

    def _detail(self, x1):
        d = self.detail_conv3(x1) + self.detail_conv5(x1)
        return self.detail_fuse(d)

    def _context(self, x1):
        c = torch.cat(
            [self.context_d1(x1), self.context_d2(x1), self.context_d3(x1)], dim=1
        )
        return self.context_fuse(c)

    def forward(self, x):
        identity = self.shortcut(x)
        x1 = self.align(x)

        if self.mode == "detail":
            f = self._detail(x1)
        elif self.mode == "context":
            f = self._context(x1)
        elif self.mode == "sum":
            f = self._detail(x1) + self._context(x1)
        else:  # 'gate'
            d = self._detail(x1)
            c = self._context(x1)
            avg_map = torch.mean(x1, dim=1, keepdim=True)
            max_map, _ = torch.max(x1, dim=1, keepdim=True)
            g = self.gate(torch.cat([avg_map, max_map], dim=1))
            f = g * d + (1.0 - g) * c

        return identity + self.out_conv(f)
