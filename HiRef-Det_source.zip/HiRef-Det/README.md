# HiRef-Det

**HiRef-Det: relation-aware high-resolution feature refinement for small-object detection in unmanned aerial vehicle imagery**

Source, paper evaluators, training records and recovered checkpoints for the VisDrone2019-DET and SeaDronesSee ODv2 experiments.

## Get the source and checkpoints

Core [modules](modules/fusion), [model configurations](configs), and [entry scripts](scripts) can be browsed directly. The complete [source package](HiRef-Det_source.zip) also contains the modified Ultralytics runtime, paper records, plotting inputs and third-party source snapshots. Expand it before running:

```bash
git clone https://github.com/zzzxinnxi/HiRef-Det.git
cd HiRef-Det
python unpack_source.py
python scripts/fetch_weights.py
```

`fetch_weights.py` places the five initial VisDrone checkpoints in `weights/` and verifies SHA-256. Use `--all` to verify/download the supplementary SeaDronesSee and ablation checkpoints. See [the checkpoint manifest](weights/manifest.json) for roles, sizes and hashes. Dataset images and annotations must be obtained separately.

## Environment

The archived YOLO training environment used Python 3.12, PyTorch 2.3.0, torchvision 0.18.0, CUDA 12.1 and a modified Ultralytics 8.4.26 runtime. Use an isolated environment:

```bash
python -m pip install torch==2.3.0 torchvision==0.18.0 --index-url https://download.pytorch.org/whl/cu121
python -m pip install -r requirements.txt
```

Choose an appropriate CPU build for CPU inference. Entry scripts select `vendor/ultralytics`; an unmodified pip installation is insufficient for the custom modules. LCDA retains its serialized implementation name `LDCA`; the manuscript's LCDA uses `sum` mode. External comparison frameworks require separate environments and their own dependencies/licenses.

## Prepare data and train

Place the VisDrone2019-DET train/validation split directories under `datasets/VisDrone/`, alongside its YAML. Each original split has `images/` and `annotations/`.

```bash
python scripts/visdrone2yolo.py --dataset-root datasets/VisDrone
python scripts/train_canonical_yolo11n_baseline.py
python scripts/train_generic.py --config yolo11n-p2-ldca-sum-csgrf-p2.yaml --name hiref_det --seed 42 --epochs 100 --batch 16
```

The model YAMLs include P2, LCDA branch/placement and CSGRF relation/sharing/placement/initialization ablations. Original `args.yaml` and `results.csv` records are under `paper/training_records/` in the source package; consult them for the exact run settings. They are historical records, so their original absolute paths are retained. Training is stochastic; a new run need not exactly reproduce a recorded value.

For SeaDronesSee ODv2, use the official images/annotation archives:

```bash
python scripts/seadronessee_prepare.py --images-zip /path/to/images.zip --annotations-zip /path/to/annotations.zip --dataset-root datasets/SeaDronesSee_ODv2
python scripts/seadronessee_train.py train baseline full
```

## Evaluate: keep the two protocols separate

Native Ultralytics validation:

```bash
python scripts/evaluate_yolo_ultralytics_paper.py --model weights/hiref_det_visdrone.pt --data datasets/VisDrone/visdrone.yaml --output-dir outputs/native_hiref --device 0
```

Unified paper COCO protocol (original-image box area, IoU 0.50:0.95, confidence 0.001, NMS IoU 0.7, image size 640, `rect=False`, `maxDets=[1,10,300]`):

```bash
python scripts/visdrone_yolo_to_coco.py --dataset-root datasets/VisDrone --output-dir datasets/VisDrone/coco
python scripts/evaluate_yolo_coco_paper.py --model HiRefDet=weights/hiref_det_visdrone.pt --images-dir datasets/VisDrone/VisDrone2019-DET-val/images --gt-json datasets/VisDrone/coco/instances_val.json --output-dir outputs/coco_hiref --category-offset 0 --device 0
```

For SeaDronesSee, first run `seadronessee_yolo_to_coco.py --dataset-root datasets/SeaDronesSee_ODv2`; use its generated validation JSON, `images/val`, and `--category-offset 1`. See each script's `--help`. Use `--device cpu` for CPU inference.

The recovered evaluators import **pycocotools**. AP is read from the accumulated precision tensor at maxDets=300; the standard summary's hard-coded AP100 entry must not be substituted. To score existing predictions (including predictions from external comparison frameworks):

```bash
python scripts/evaluate_coco_predictions_paper.py --gt-json /path/to/instances_val.json --predictions /path/to/predictions.json --output outputs/metrics.json --log outputs/cocoeval.txt
```

Use `profile_yolo_paper.py` for the recovered FP32 profiling procedure. Native mAP, unified COCO AP, and class-wise AP are distinct quantities. The obsolete `reeval_csgrf_multiseed.py` is excluded because its `APS` field used class-0 AP rather than small-object AP.

## Paper assets and traceability

After expansion, `paper/evaluation_records/` contains compact metrics, resolved comparison configs and audit artifacts. `paper/training_records/index.json` indexes selected run records, and `paper/recovery_audit.json` describes recovery coverage. The [paper asset guide](paper/README.md) maps these materials to experiment families.

`archives/figure_generation.zip` contains recovered plotting scripts and selected-image/confusion-matrix inputs. Original plotting scripts retain historical dataset/checkpoint paths and need local path adaptation. `archives/final_figure_edits.zip` preserves the later local Figure 6/7/8 edits and Figure 8 replay coordinates; the local edit scripts also require path/font adaptation. `archives/final_figure_edits.zip` preserves the later local Figure 6/7/8 edits and Figure 8 replay coordinates; the local edit scripts also require path/font adaptation. Image datasets are not redistributed. External framework source snapshots and original runtime variants are stored separately in `archives/`, with hashes/revisions in `framework_index.json`; consult upstream repositories for non-Python build assets and dependencies.

## Validation and scope

Five experiment instances were independently scanned and recovered files were checked against SHA-256 manifests. A sixth drawing-only instance was excluded based on the prior handoff; it was not independently rescanned. Dataset images, oversized prediction JSON, failed architecture experiments and cloud orchestration/shutdown helpers are excluded. NanoDet's custom config and profiler are included, but its original full framework snapshot and exact source revision were not recovered. Trained MMDetection/RT-DETR/NanoDet comparison checkpoints are not all included; recovered configs, records and framework sources are supplied for those comparisons. Literature-only comparison rows are attributed published results rather than locally reproduced experiments.

The package is checked for Python syntax, archive integrity and checkpoint hashes. See `paper/VALIDATION.md` for executed runtime checks and their limits. Full training and full-dataset evaluation have not been rerun as part of packaging.

## License

The modified Ultralytics-based project is distributed under [AGPL-3.0](LICENSE). External framework archives retain their upstream notices and licenses. See [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md).
