"""Expand the complete source archive into this checkout (no dataset/weights)."""
from pathlib import Path
import shutil, zipfile
root=Path(__file__).resolve().parent
with zipfile.ZipFile(root/'HiRef-Det_source.zip') as z:
    for info in z.infolist():
        rel=Path(info.filename)
        if rel.parts and rel.parts[0]=='HiRef-Det':rel=Path(*rel.parts[1:])
        if not rel.parts:continue
        target=(root/rel).resolve()
        if not target.is_relative_to(root) or info.is_dir():continue
        target.parent.mkdir(parents=True,exist_ok=True)
        with z.open(info) as src,target.open('wb') as dst:shutil.copyfileobj(src,dst)
print('Source expanded. Install dependencies and prepare datasets as described in README.md.')
