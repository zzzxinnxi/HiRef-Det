# Third-party notices

The `vendor/ultralytics` directory contains the modified Ultralytics 8.4.26 source downloaded from the training environment. Upstream: https://github.com/ultralytics/ultralytics . Its AGPL-3.0 license headers are retained; the complete license is in `LICENSE` (retrieved from upstream tag v8.4.26).

The custom model modules import and extend this runtime. The source bundle is distributed under AGPL-3.0. The included pretrained YOLO11n checkpoint originates from Ultralytics; the other four checkpoints were recovered from this project's VisDrone training runs. Dataset images and annotations are not distributed in this bundle.

Recovered external comparison source snapshots are indexed in `archives/framework_index.json` after source expansion. Each archive retains its available upstream license files and source headers. They remain subject to their respective licenses; the root AGPL notice does not relicense these third-party projects. Non-Python native build assets and pretrained dependencies should be obtained from the matching upstream revision.
