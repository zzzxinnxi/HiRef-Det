# Initial VisDrone source release

Recovered from the VisDrone training instance on 2026-10-21 and packaged on 2026-10-22. The five checkpoints are byte-for-byte unchanged, with verified SHA-256 values.

Selected: YOLO11n canonical batch-16 baseline, P2, P2+LCDA, and HiRef-Det; model configurations, the LCDA/CSGRF implementations, dataset conversion scripts, and each run's args.yaml/results.csv. Historical args.yaml files retain their original training paths. Unrelated/failed experiment files, datasets and SSH utilities are excluded.

Packaging edits: removed the unused SHARP initializer import; made runtime, training and dataset paths portable; selected the bundled pretrained checkpoint; added runtime bootstrap and prediction entry points; used checkpoint-specific native-evaluation labels; added default mode fallbacks for older CSGRF checkpoints. The serialized class LDCA and its explicit sum mode are preserved. No learned tensors or model configurations were changed.

Static Python syntax checks, archive integrity checks and checkpoint hash checks were performed. Model loading, inference, training and clean-environment installation have not yet been verified for this packaged copy.

Archived environment: Python 3.12.3, torch 2.3.0+cu121, torchvision 0.18.0+cu121, modified Ultralytics 8.4.26. Other observed versions: numpy 2.4.6, OpenCV 4.13.0.92, scipy 1.17.1, matplotlib 3.9.0, Pillow 10.3.0. requirements.txt is a suggested dependency set with NumPy 1.x for torch 2.3 compatibility, not a verified exact environment lock.
