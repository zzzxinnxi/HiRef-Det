"""Traceable FP32 complexity and latency profiling for MMDetection checkpoints."""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import platform
import statistics
import sys
import time
from pathlib import Path

import mmcv
import mmengine
import mmdet
import torch
import torch.nn as nn
from mmengine.config import Config
from mmengine.analysis import get_model_complexity_info
from mmdet.registry import MODELS
from mmdet.utils import register_all_modules


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


class RawDetectorForward(nn.Module):
    """Expose detector tensor mode without preprocessing, decoding, or NMS."""

    def __init__(self, detector: nn.Module) -> None:
        super().__init__()
        self.detector = detector

    def forward(self, images: torch.Tensor):
        return self.detector._forward(images, None)


def select_state(checkpoint: dict, use_ema: bool) -> tuple[dict, str]:
    if use_ema and "ema_state_dict" in checkpoint:
        ema = checkpoint["ema_state_dict"]
        state = {
            key.removeprefix("module."): value
            for key, value in ema.items()
            if key != "steps"
        }
        return state, "ema_state_dict.module"
    if "state_dict" in checkpoint:
        return checkpoint["state_dict"], "state_dict"
    raise KeyError(f"Unsupported checkpoint keys: {list(checkpoint)}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--name", required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--imgsz", type=int, default=640)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--warmup", type=int, default=50)
    parser.add_argument("--timed-runs", type=int, default=200)
    parser.add_argument("--repeats", type=int, default=5)
    parser.add_argument("--no-ema", action="store_true")
    args = parser.parse_args()

    config_path = args.config.expanduser().resolve()
    checkpoint_path = args.checkpoint.expanduser().resolve()
    output_path = args.output.expanduser().resolve()
    if not config_path.is_file() or not checkpoint_path.is_file():
        raise FileNotFoundError(f"Missing config or checkpoint: {config_path}, {checkpoint_path}")

    register_all_modules(init_default_scope=True)
    cfg = Config.fromfile(config_path)
    detector = MODELS.build(cfg.model)
    raw_checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    state, selected_state = select_state(raw_checkpoint, use_ema=not args.no_ema)
    incompatible = detector.load_state_dict(state, strict=True)
    detector.eval()

    params = sum(parameter.numel() for parameter in detector.parameters())
    trainable_params = sum(parameter.numel() for parameter in detector.parameters() if parameter.requires_grad)
    device = torch.device(args.device)
    detector = detector.to(device).eval()
    wrapper = RawDetectorForward(detector).to(device).eval()
    dummy = torch.zeros(1, 3, args.imgsz, args.imgsz, dtype=torch.float32, device=device)

    # Keep latency measurement independent from the complexity trace.
    latency_wrapper = copy.deepcopy(wrapper).eval()

    with torch.inference_mode():
        complexity = get_model_complexity_info(
            wrapper,
            None,
            inputs=dummy,
            show_table=False,
            show_arch=False,
        )
    single_fma_flops = float(complexity["flops"])

    fusion_applied = False
    try:
        from mmengine.model.utils import fuse_conv_bn

        latency_wrapper = fuse_conv_bn(latency_wrapper)
        fusion_applied = True
    except (ImportError, TypeError, AttributeError):
        try:
            from mmcv.cnn import fuse_conv_bn

            latency_wrapper = fuse_conv_bn(latency_wrapper)
            fusion_applied = True
        except (ImportError, TypeError, AttributeError):
            fusion_applied = False
    latency_wrapper = latency_wrapper.to(device).eval()
    torch.backends.cudnn.benchmark = True

    repeat_means_ms = []
    with torch.inference_mode():
        for _ in range(args.warmup):
            latency_wrapper(dummy)
        torch.cuda.synchronize(device)
        for _ in range(args.repeats):
            start = time.perf_counter()
            for _ in range(args.timed_runs):
                latency_wrapper(dummy)
            torch.cuda.synchronize(device)
            repeat_means_ms.append((time.perf_counter() - start) * 1000.0 / args.timed_runs)

    latency_ms = statistics.median(repeat_means_ms)
    gpu_properties = torch.cuda.get_device_properties(device)
    meta = raw_checkpoint.get("meta", {})
    result = {
        "model": args.name,
        "checkpoint": {
            "path": str(checkpoint_path),
            "sha256": sha256(checkpoint_path),
            "size_bytes": checkpoint_path.stat().st_size,
            "selected_state": selected_state,
            "checkpoint_keys": list(raw_checkpoint),
            "meta_epoch": meta.get("epoch"),
            "meta_iter": meta.get("iter"),
            "experiment_name": meta.get("experiment_name"),
        },
        "config": {"path": str(config_path), "sha256": sha256(config_path)},
        "load": {
            "strict": True,
            "missing_keys": list(incompatible.missing_keys),
            "unexpected_keys": list(incompatible.unexpected_keys),
        },
        "metrics": {
            "params": int(params),
            "params_m": params / 1e6,
            "trainable_params": int(trainable_params),
            "mmengine_analyzer_params": int(complexity["params"]),
            "gmacs": single_fma_flops / 1e9,
            "gflops": 2.0 * single_fma_flops / 1e9,
            "latency_ms_median": latency_ms,
            "fps": 1000.0 / latency_ms,
            "latency_repeats_ms": repeat_means_ms,
        },
        "protocol": {
            "input_shape": [1, 3, args.imgsz, args.imgsz],
            "precision": "FP32",
            "batch_size": 1,
            "params_and_macs_model": "native tensor graph before Conv-BN fusion",
            "latency_model": "native tensor graph without preprocessing, decoding, or NMS",
            "conv_bn_fused_for_latency": fusion_applied,
            "warmup_runs": args.warmup,
            "timed_runs_per_repeat": args.timed_runs,
            "repeats": args.repeats,
            "reported_latency": "median of repeat means",
            "complexity_analyzer": "MMEngine get_model_complexity_info",
            "complexity_raw_convention": "one fused multiply-add counted as one operation",
            "gflops_definition": "multiply and add count as two operations; reported GFLOPs=2x raw analyzer operations",
        },
        "runtime": {
            "python": sys.version,
            "executable": sys.executable,
            "platform": platform.platform(),
            "cwd": os.getcwd(),
            "torch": torch.__version__,
            "mmcv": mmcv.__version__,
            "mmengine": mmengine.__version__,
            "mmdet": mmdet.__version__,
            "cuda": torch.version.cuda,
            "cudnn": torch.backends.cudnn.version(),
            "gpu": gpu_properties.name,
            "gpu_total_memory": gpu_properties.total_memory,
        },
    }

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(result, indent=2, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
