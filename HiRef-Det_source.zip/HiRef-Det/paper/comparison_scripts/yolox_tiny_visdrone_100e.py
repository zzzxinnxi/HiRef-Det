"""YOLOX-tiny comparison protocol for VisDrone2019-DET validation."""

_base_ = '../yolox/yolox_tiny_8xb8-300e_coco.py'

data_root = '/root/autodl-tmp/YOLO-Research/datasets/VisDrone/'
work_dir = '/root/autodl-tmp/YOLO-Research/runs/detect_comparison/yolox_tiny_visdrone'
load_from = '/root/autodl-tmp/yolox_tiny_8x8_300e_coco_20211124_171234-b4047906.pth'

class_names = (
    'pedestrian',
    'people',
    'bicycle',
    'car',
    'van',
    'truck',
    'tricycle',
    'awning-tricycle',
    'bus',
    'motor',
)
metainfo = dict(classes=class_names)
img_scale = (640, 640)

model = dict(
    # Keep training and validation at exactly 640 x 640.
    data_preprocessor=dict(batch_augments=None),
    bbox_head=dict(num_classes=10),
    test_cfg=dict(max_per_img=300),
)

train_pipeline = [
    dict(type='Mosaic', img_scale=img_scale, pad_val=114.0),
    dict(
        type='RandomAffine',
        scaling_ratio_range=(0.5, 1.5),
        border=(-img_scale[0] // 2, -img_scale[1] // 2)),
    dict(type='YOLOXHSVRandomAug'),
    dict(type='RandomFlip', prob=0.5),
    dict(type='Resize', scale=img_scale, keep_ratio=True),
    dict(
        type='Pad',
        pad_to_square=True,
        pad_val=dict(img=(114.0, 114.0, 114.0))),
    dict(type='FilterAnnotations', min_gt_bbox_wh=(1, 1), keep_empty=False),
    dict(type='PackDetInputs'),
]

test_pipeline = [
    dict(type='LoadImageFromFile'),
    dict(type='Resize', scale=img_scale, keep_ratio=True),
    dict(
        type='Pad',
        pad_to_square=True,
        pad_val=dict(img=(114.0, 114.0, 114.0))),
    dict(type='LoadAnnotations', with_bbox=True),
    dict(
        type='PackDetInputs',
        meta_keys=('img_id', 'img_path', 'ori_shape', 'img_shape',
                   'scale_factor')),
]

train_dataloader = dict(
    batch_size=16,
    num_workers=8,
    persistent_workers=True,
    dataset=dict(
        dataset=dict(
            data_root=data_root,
            ann_file='coco_annotations/instances_train.json',
            data_prefix=dict(img='VisDrone2019-DET-train/images/'),
            metainfo=metainfo,
            filter_cfg=dict(filter_empty_gt=False, min_size=1)),
        pipeline=train_pipeline),
)
val_dataloader = dict(
    batch_size=8,
    num_workers=8,
    persistent_workers=True,
    dataset=dict(
        data_root=data_root,
        ann_file='coco_annotations/instances_val.json',
        data_prefix=dict(img='VisDrone2019-DET-val/images/'),
        metainfo=metainfo,
        test_mode=True,
        pipeline=test_pipeline),
)
test_dataloader = val_dataloader

val_evaluator = dict(
    ann_file=data_root + 'coco_annotations/instances_val.json',
    metric='bbox',
    proposal_nums=(1, 10, 300),
    classwise=True,
)
test_evaluator = val_evaluator

max_epochs = 100
num_last_epochs = 15
base_lr = 0.0025  # Official 0.01 scaled from global batch 64 to batch 16.

train_cfg = dict(max_epochs=max_epochs, val_interval=1)
optim_wrapper = dict(optimizer=dict(lr=base_lr))
param_scheduler = [
    dict(
        type='mmdet.QuadraticWarmupLR',
        by_epoch=True,
        begin=0,
        end=5,
        convert_to_iter_based=True),
    dict(
        type='CosineAnnealingLR',
        eta_min=base_lr * 0.05,
        begin=5,
        T_max=max_epochs - num_last_epochs,
        end=max_epochs - num_last_epochs,
        by_epoch=True,
        convert_to_iter_based=True),
    dict(
        type='ConstantLR',
        by_epoch=True,
        factor=1,
        begin=max_epochs - num_last_epochs,
        end=max_epochs),
]

default_hooks = dict(
    checkpoint=dict(
        interval=1,
        save_best='coco/bbox_mAP',
        rule='greater',
        max_keep_ckpts=3),
)
custom_hooks = [
    dict(
        type='YOLOXModeSwitchHook',
        num_last_epochs=num_last_epochs,
        priority=48),
    dict(type='SyncNormHook', priority=48),
    dict(
        type='EMAHook',
        ema_type='ExpMomentumEMA',
        momentum=0.0001,
        update_buffers=True,
        priority=49),
]

randomness = dict(seed=42, deterministic=False)
log_processor = dict(window_size=50, by_epoch=True)
