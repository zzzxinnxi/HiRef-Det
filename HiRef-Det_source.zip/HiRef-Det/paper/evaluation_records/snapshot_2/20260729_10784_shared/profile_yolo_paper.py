"""Traceable FP32 complexity and latency profiling for YOLO checkpoints."""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import statistics
import sys
import time
from pathlib import Path

import torch
from ultralytics import YOLO, __version__ as ultralytics_version
from ultralytics.utils.torch_utils import get_flops


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_model(value: str) -> tuple[str, Path]:
    if "=" not in value:
        raise argparse.ArgumentTypeError("Model must use NAME=/absolute/path/to/best.pt")
    name, raw_path = value.split("=", 1)
    path = Path(raw_path).expanduser().resolve()
    if not name.strip() or not path.is_file():
        raise argparse.ArgumentTypeError(f"Invalid model specification: {value}")
    return name.strip(), path


def profile(
    name: str,
    weight: Path,
    imgsz: int,
    device: str,
    warmup: int,
    timed_runs: int,
    repeats: int,
) -> dict:
    yolo = YOLO(str(weight))
    model = yolo.model.eval()
    params = sum(parameter.numel() for parameter in model.parameters())
    trainable_params = sum(parameter.numel() for parameter in model.parameters() if parameter.requires_grad)
    gflops = float(get_flops(model, imgsz=imgsz))
    gmacs = gflops / 2.0

    try:
        model.fuse(verbose=False)
    except TypeError:
        model.fuse()
    target = torch.device(f"cuda:{device}" if str(device).isdigit() else device)
    model = model.to(target).eval()
    dummy = torch.zeros(1, 3, imgsz, imgsz, dtype=torch.float32, device=target)
    torch.backends.cudnn.benchmark = True

    latencies_ms = []
    with torch.inference_mode():
        for _ in range(warmup):
            model(dummy)
        torch.cuda.synchronize(target)
        for _ in range(repeats):
            start = time.perf_counter()
            for _ in range(timed_runs):
                model(dummy)
            torch.cuda.synchronize(target)
            latencies_ms.append((time.perf_counter() - start) * 1000.0 / timed_runs)

    latency_ms = statistics.median(latencies_ms)
    return {
        "model": name,
        "weight": {
            "path": str(weight),
            "sha256": sha256(weight),
            "size_bytes": weight.stat().st_size,
            "mtime_ns": weight.stat().st_mtime_ns,
        },
        "metrics": {
            "params": params,
            "params_m": params / 1e6,
            "trainable_params": trainable_params,
            "gmacs": gmacs,
            "gflops": gflops,
            "latency_ms_median": latency_ms,
            "fps": 1000.0 / latency_ms,
            "latency_repeats_ms": latencies_ms,
        },
        "protocol": {
            "input_shape": [1, 3, imgsz, imgsz],
            "precision": "FP32",
            "conv_bn_fused": True,
            "warmup_runs": warmup,
            "timed_runs_per_repeat": timed_runs,
            "repeats": repeats,
            "reported_latency": "median of repeat means",
            "gflops_definition": "multiply and add count as two operations",
        },
        "runtime": {
            "python": sys.version,
            "platform": platform.platform(),
            "torch": torch.__version__,
            "ultralytics": ultralytics_version,
            "cuda": torch.version.cuda,
            "cudnn": torch.backends.cudnn.version(),
            "gpu": torch.cuda.get_device_name(target),
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", action="append", type=parse_model, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--imgsz", type=int, default=640)
    parser.add_argument("--device", default="0")
    parser.add_argument("--warmup", type=int, default=50)
    parser.add_argument("--timed-runs", type=int, default=200)
    parser.add_argument("--repeats", type=int, default=5)
    args = parser.parse_args()

    payloads = []
    for name, weight in args.model:
        print(f"Profiling {name}: {weight}", flush=True)
        payloads.append(
            profile(name, weight, args.imgsz, args.device, args.warmup, args.timed_runs, args.repeats)
        )
        torch.cuda.empty_cache()
    args.output.resolve().parent.mkdir(parents=True, exist_ok=True)
    args.output.resolve().write_text(json.dumps(payloads, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(payloads, indent=2, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
