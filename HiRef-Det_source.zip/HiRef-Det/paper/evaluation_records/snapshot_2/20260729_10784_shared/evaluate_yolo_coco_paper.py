"""Evaluate YOLO checkpoints with one traceable COCO protocol.

This script intentionally writes predictions, hashes, package versions, and
the complete COCO metric vector so every paper-table value can be audited.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import sys
import time
from contextlib import redirect_stdout
from pathlib import Path

import numpy as np
import torch
from pycocotools.coco import COCO
from pycocotools.cocoeval import COCOeval
from ultralytics import YOLO, __version__ as ultralytics_version


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_model(value: str) -> tuple[str, Path]:
    if "=" not in value:
        raise argparse.ArgumentTypeError("Model must use NAME=/absolute/path/to/best.pt")
    name, raw_path = value.split("=", 1)
    path = Path(raw_path).expanduser().resolve()
    if not name.strip() or not path.is_file():
        raise argparse.ArgumentTypeError(f"Invalid model specification: {value}")
    return name.strip(), path


def xyxy_to_xywh(xyxy: list[float]) -> list[float]:
    x1, y1, x2, y2 = xyxy
    return [x1, y1, max(0.0, x2 - x1), max(0.0, y2 - y1)]


def run_coco_eval(gt_json: Path, predictions: list[dict], log_path: Path) -> dict[str, float]:
    coco_gt = COCO(str(gt_json))
    if not predictions:
        raise RuntimeError("No predictions were produced")
    coco_dt = coco_gt.loadRes(predictions)
    evaluator = COCOeval(coco_gt, coco_dt, "bbox")
    evaluator.params.maxDets = [1, 10, 300]
    evaluator.params.imgIds = sorted(coco_gt.getImgIds())
    evaluator.params.catIds = sorted(coco_gt.getCatIds())
    evaluator.evaluate()
    evaluator.accumulate()
    with log_path.open("w", encoding="utf-8") as handle, redirect_stdout(handle):
        evaluator.summarize()

    # pycocotools' built-in summary hard-codes maxDets=100 for several AP
    # entries. Read the accumulated tensors directly so AP and AR consistently
    # use the requested paper protocol maxDets=300.
    precision = evaluator.eval["precision"]  # T x R x K x A x M
    recall = evaluator.eval["recall"]  # T x K x A x M
    max_det_index = evaluator.params.maxDets.index(300)
    area_index = {label: index for index, label in enumerate(evaluator.params.areaRngLbl)}

    def valid_mean(values: np.ndarray) -> float:
        valid = values[values > -1]
        return float(valid.mean()) if valid.size else -1.0

    def ap(iou_index: int | None, area_label: str) -> float:
        values = precision[:, :, :, area_index[area_label], max_det_index]
        if iou_index is not None:
            values = values[iou_index : iou_index + 1]
        return valid_mean(values)

    def ar(area_label: str, max_dets: int) -> float:
        index = evaluator.params.maxDets.index(max_dets)
        return valid_mean(recall[:, :, area_index[area_label], index])

    return {
        "ap": ap(None, "all"),
        "ap50": ap(0, "all"),
        "ap75": ap(5, "all"),
        "aps": ap(None, "small"),
        "apm": ap(None, "medium"),
        "apl": ap(None, "large"),
        "ar1": ar("all", 1),
        "ar10": ar("all", 10),
        "ar300": ar("all", 300),
        "ars": ar("small", 300),
        "arm": ar("medium", 300),
        "arl": ar("large", 300),
    }


def evaluate_model(
    name: str,
    weight: Path,
    images_dir: Path,
    gt_json: Path,
    output_dir: Path,
    imgsz: int,
    batch: int,
    device: str,
    conf: float,
    iou: float,
    max_det: int,
    workers: int,
    category_offset: int,
) -> dict:
    safe_name = "".join(character if character.isalnum() else "_" for character in name).strip("_").lower()
    model_dir = output_dir / safe_name
    model_dir.mkdir(parents=True, exist_ok=True)
    prediction_path = model_dir / "predictions.json"
    metric_path = model_dir / "metrics.json"
    log_path = model_dir / "cocoeval.txt"

    gt = json.loads(gt_json.read_text(encoding="utf-8"))
    image_id_by_name = {image["file_name"]: int(image["id"]) for image in gt["images"]}
    category_ids = {int(category["id"]) for category in gt["categories"]}
    sources = [images_dir / image["file_name"] for image in gt["images"]]
    missing = [str(path) for path in sources if not path.is_file()]
    if missing:
        raise FileNotFoundError(f"Missing {len(missing)} evaluation images; first={missing[0]}")

    model = YOLO(str(weight))
    start = time.time()
    results = model.predict(
        # Directory input preserves original file names. Passing a Python list
        # makes some Ultralytics versions rename items to image0.jpg, which
        # breaks the auditable image-id mapping against COCO ground truth.
        source=str(images_dir),
        imgsz=imgsz,
        batch=batch,
        device=device,
        conf=conf,
        iou=iou,
        max_det=max_det,
        rect=False,
        workers=workers,
        save=False,
        verbose=False,
        stream=True,
    )

    predictions: list[dict] = []
    seen_image_ids: set[int] = set()
    for result in results:
        file_name = Path(result.path).name
        if file_name not in image_id_by_name:
            raise KeyError(f"Prediction image is absent from GT JSON: {file_name}")
        image_id = image_id_by_name[file_name]
        seen_image_ids.add(image_id)
        boxes = result.boxes
        if boxes is None or len(boxes) == 0:
            continue
        xyxy_rows = boxes.xyxy.detach().cpu().tolist()
        score_rows = boxes.conf.detach().cpu().tolist()
        class_rows = boxes.cls.detach().cpu().to(torch.int64).tolist()
        for xyxy, score, class_id in zip(xyxy_rows, score_rows, class_rows):
            category_id = int(class_id) + category_offset
            if category_id not in category_ids:
                raise ValueError(f"Predicted category {category_id} is absent from GT categories")
            predictions.append(
                {
                    "image_id": image_id,
                    "category_id": category_id,
                    "bbox": [round(value, 5) for value in xyxy_to_xywh(xyxy)],
                    "score": round(float(score), 8),
                }
            )

    if len(seen_image_ids) != len(sources):
        raise RuntimeError(f"Only evaluated {len(seen_image_ids)}/{len(sources)} images")
    prediction_path.write_text(json.dumps(predictions, ensure_ascii=True), encoding="ascii")
    metrics = run_coco_eval(gt_json, predictions, log_path)
    elapsed_seconds = time.time() - start

    payload = {
        "model": name,
        "weight": {
            "path": str(weight),
            "sha256": sha256(weight),
            "size_bytes": weight.stat().st_size,
            "mtime_ns": weight.stat().st_mtime_ns,
        },
        "ground_truth": {
            "path": str(gt_json.resolve()),
            "sha256": sha256(gt_json),
            "images": len(gt["images"]),
            "annotations": len(gt["annotations"]),
            "categories": len(gt["categories"]),
        },
        "protocol": {
            "images_dir": str(images_dir.resolve()),
            "imgsz": imgsz,
            "batch": batch,
            "device": device,
            "confidence_threshold": conf,
            "nms_iou_threshold": iou,
            "rectangular_minimal_padding": False,
            "max_dets": [1, 10, 300],
            "category_offset": category_offset,
            "area_ranges_original_pixels": {
                "small": "area < 32^2",
                "medium": "32^2 <= area < 96^2",
                "large": "area >= 96^2",
            },
        },
        "runtime": {
            "elapsed_seconds_including_cocoeval": elapsed_seconds,
            "predictions": len(predictions),
            "python": sys.version,
            "platform": platform.platform(),
            "torch": torch.__version__,
            "ultralytics": ultralytics_version,
            "numpy": np.__version__,
            "cuda": torch.version.cuda,
            "gpu": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
        },
        "metrics": metrics,
        "artifacts": {
            "predictions_json": str(prediction_path.resolve()),
            "cocoeval_log": str(log_path.resolve()),
        },
    }
    metric_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    return payload


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", action="append", type=parse_model, required=True)
    parser.add_argument("--images-dir", type=Path, required=True)
    parser.add_argument("--gt-json", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--imgsz", type=int, default=640)
    parser.add_argument("--batch", type=int, default=16)
    parser.add_argument("--device", default="0")
    parser.add_argument("--conf", type=float, default=0.001)
    parser.add_argument("--iou", type=float, default=0.7)
    parser.add_argument("--max-det", type=int, default=300)
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--category-offset", type=int, default=0)
    args = parser.parse_args()

    images_dir = args.images_dir.resolve()
    gt_json = args.gt_json.resolve()
    output_dir = args.output_dir.resolve()
    if not images_dir.is_dir() or not gt_json.is_file():
        raise FileNotFoundError(f"Invalid dataset paths: images={images_dir}, gt={gt_json}")
    output_dir.mkdir(parents=True, exist_ok=True)

    summaries = []
    for name, weight in args.model:
        print(f"Evaluating {name}: {weight}", flush=True)
        payload = evaluate_model(
            name,
            weight,
            images_dir,
            gt_json,
            output_dir,
            args.imgsz,
            args.batch,
            args.device,
            args.conf,
            args.iou,
            args.max_det,
            args.workers,
            args.category_offset,
        )
        summaries.append(
            {
                "model": name,
                "weight_sha256": payload["weight"]["sha256"],
                **payload["metrics"],
            }
        )
        torch.cuda.empty_cache()
    (output_dir / "summary.json").write_text(
        json.dumps(summaries, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(summaries, indent=2, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
