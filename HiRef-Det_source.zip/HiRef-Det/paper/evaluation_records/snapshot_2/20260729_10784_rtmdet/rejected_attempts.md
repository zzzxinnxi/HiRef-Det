# Rejected RTMDet profiling attempts

These files are retained only for audit and must not be used in paper tables.

1. `rtmdet_tiny_profile.log`: the first THOP run failed during latency warmup because temporary THOP hooks were copied after their buffers had been removed.
2. `rtmdet_tiny_profile.json` and `rtmdet_tiny_profile_corrected.log`: this run selected `ema_state_dict.module`. MMEngine `EMAHook` swaps checkpoint fields before saving, so this field contains the original training weights. The deployment/validation EMA weights are in `state_dict`.
3. THOP also over-counted RTMDet because the shared head convolution objects received duplicate hooks. The accepted complexity uses MMEngine `get_model_complexity_info` and converts its single-FMA convention to the paper convention with `GFLOPs = 2 x GMACs`.

Accepted final artifacts:

- `rtmdet_tiny_profile_state_dict_ema.json`
- `rtmdet_tiny_profile_state_dict_ema.log`
- `rtmdet_tiny_coco_metrics.json`
- `predictions/rtmdet_tiny_epoch99.bbox.json`
