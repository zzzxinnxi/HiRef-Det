# SeaDronesSee YOLO evaluation audit note

The first combined evaluation invocation completed YOLOv8n, YOLOv10n, and YOLOv11n, then stopped at YOLOv12n because the global Ultralytics `AAttn` implementation expected `qkv` while the serialized YOLOv12 model used its native `qk` implementation.

No completed model was rerun. YOLOv12n was subsequently evaluated with the isolated official YOLOv12 source tree, and YOLOv11n+P2+LCDA+CSGRF was evaluated separately in the native project environment. The final evidence folder is complete only after all five model directories contain `metrics.json`, `predictions.json`, and `cocoeval.txt`.

The initial compatibility failure is retained for audit and must not be interpreted as a failed model result.
