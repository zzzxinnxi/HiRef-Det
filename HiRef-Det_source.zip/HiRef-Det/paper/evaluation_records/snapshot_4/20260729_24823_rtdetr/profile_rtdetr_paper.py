"""Traceable FP32 complexity and latency profiling for native RT-DETR checkpoints."""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import platform
import statistics
import sys
import time
from pathlib import Path

import torch
from thop import profile as thop_profile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.core import YAMLConfig  # noqa: E402


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--imgsz", type=int, default=640)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--warmup", type=int, default=50)
    parser.add_argument("--timed-runs", type=int, default=200)
    parser.add_argument("--repeats", type=int, default=5)
    args = parser.parse_args()

    config = args.config.expanduser().resolve()
    checkpoint = args.checkpoint.expanduser().resolve()
    output = args.output.expanduser().resolve()
    if not config.is_file() or not checkpoint.is_file():
        raise FileNotFoundError(f"Missing config or checkpoint: {config}, {checkpoint}")

    cfg = YAMLConfig(str(config))
    raw_checkpoint = torch.load(checkpoint, map_location="cpu", weights_only=False)
    if "ema" in raw_checkpoint:
        state = raw_checkpoint["ema"]["module"]
        selected_state = "ema.module"
    elif "model" in raw_checkpoint:
        state = raw_checkpoint["model"]
        selected_state = "model"
    else:
        raise KeyError(f"Unsupported checkpoint keys: {list(raw_checkpoint)}")

    incompatible = cfg.model.load_state_dict(state, strict=True)
    model = cfg.model.eval()
    params = sum(parameter.numel() for parameter in model.parameters())
    trainable_params = sum(parameter.numel() for parameter in model.parameters() if parameter.requires_grad)

    device = torch.device(args.device)
    model = model.to(device).eval()
    dummy = torch.zeros(1, 3, args.imgsz, args.imgsz, dtype=torch.float32, device=device)

    with torch.inference_mode():
        macs, thop_params = thop_profile(model, inputs=(dummy,), verbose=False)

    latency_model = copy.deepcopy(model).eval()
    if hasattr(latency_model, "deploy"):
        latency_model = latency_model.deploy()
    latency_model = latency_model.to(device).eval()
    torch.backends.cudnn.benchmark = True

    repeat_means_ms = []
    with torch.inference_mode():
        for _ in range(args.warmup):
            latency_model(dummy)
        torch.cuda.synchronize(device)
        for _ in range(args.repeats):
            start = time.perf_counter()
            for _ in range(args.timed_runs):
                latency_model(dummy)
            torch.cuda.synchronize(device)
            repeat_means_ms.append((time.perf_counter() - start) * 1000.0 / args.timed_runs)

    latency_ms = statistics.median(repeat_means_ms)
    gpu_properties = torch.cuda.get_device_properties(device)
    result = {
        "model": "RT-DETR-R18VD",
        "checkpoint": {
            "path": str(checkpoint),
            "sha256": sha256(checkpoint),
            "size_bytes": checkpoint.stat().st_size,
            "selected_state": selected_state,
            "checkpoint_keys": list(raw_checkpoint),
        },
        "config": {
            "path": str(config),
            "sha256": sha256(config),
        },
        "load": {
            "strict": True,
            "missing_keys": list(incompatible.missing_keys),
            "unexpected_keys": list(incompatible.unexpected_keys),
        },
        "metrics": {
            "params": int(params),
            "params_m": params / 1e6,
            "trainable_params": int(trainable_params),
            "thop_params": int(thop_params),
            "gmacs": macs / 1e9,
            "gflops": 2.0 * macs / 1e9,
            "latency_ms_median": latency_ms,
            "fps": 1000.0 / latency_ms,
            "latency_repeats_ms": repeat_means_ms,
        },
        "protocol": {
            "input_shape": [1, 3, args.imgsz, args.imgsz],
            "precision": "FP32",
            "batch_size": 1,
            "params_and_macs_model": "native eval graph before deploy conversion",
            "latency_model": "native deploy graph without preprocessing or postprocessing",
            "warmup_runs": args.warmup,
            "timed_runs_per_repeat": args.timed_runs,
            "repeats": args.repeats,
            "reported_latency": "median of repeat means",
            "gflops_definition": "multiply and add count as two operations",
        },
        "runtime": {
            "python": sys.version,
            "executable": sys.executable,
            "platform": platform.platform(),
            "cwd": os.getcwd(),
            "torch": torch.__version__,
            "cuda": torch.version.cuda,
            "cudnn": torch.backends.cudnn.version(),
            "gpu": gpu_properties.name,
            "gpu_total_memory": gpu_properties.total_memory,
        },
    }

    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(result, indent=2, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
