# Paper asset guide

The complete source ZIP preserves the nested records and third-party materials. Expand it using `python unpack_source.py` from the repository root.

| Experiment family | Implementation and evidence |
|---|---|
| Native VisDrone model comparison | `scripts/evaluate_yolo_ultralytics_paper.py`; selected YOLO run records |
| Unified VisDrone / SeaDronesSee COCO comparison | `scripts/evaluate_yolo_coco_paper.py`, `scripts/evaluate_coco_predictions_paper.py`; `evaluation_records/` compact metrics and resolved configs |
| Baseline, P2, LCDA, CSGRF and full detector | `configs/`, `modules/fusion/`; `training_records/index.json` and checkpoint manifest |
| LCDA detail/context/sum and placement | LCDA YAML variants and `LDCA` implementation; records named `ldca_context`, `ldca_detail`, `ldca_sum`, `lcda_p3`, `lcda_p2p3` |
| CSGRF scalar/adaptive controls | `ScalarWeightedConcat`, `AdaptiveCompetitiveConcat` classes; scalar/adaptive YAMLs and recovered run records |
| CSGRF relations, sharing, alpha initialization, placement and seeds | CSGRF YAMLs, `alpha_init` option; shared/full multi-seed records and weights |
| Parameter / FLOP / FP32 latency | `scripts/profile_yolo_paper.py`; original external profiling scripts in evaluation records |
| Figures | `archives/figure_generation.zip`; historical paths require adaptation |
| Published-method literature comparison | Cited external papers; not locally reproduced runs |

Source labels in the record tree distinguish recovered snapshots; they are not experiment conditions. Byte-identical weights are deduplicated by SHA-256. Different run names can point to the same checkpoint. Formal LCDA uses `sum`; early gate-mode trials are not included as formal LCDA runs.

The final model defaults are independent branch calibration, additive-plus-multiplicative relations, and zero-initialized residual scales. The combined CSGRF API appends `alpha_init` after mode arguments; the recovered alpha=1 YAML is adjusted to that API. Other formal model defaults are unchanged. Serialized class names are preserved. Original module/parser versions are archived for tracing.
