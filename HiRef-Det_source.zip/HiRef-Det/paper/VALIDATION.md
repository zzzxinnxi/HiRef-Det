# Packaging validation

Validated on 2026-11-07 using the packaged source in an isolated temporary directory on a recovered CPU instance. The import path was verified to use `vendor/ultralytics` from this package.

- All 15 released model YAMLs constructed and completed an evaluation-mode CPU forward pass with a synthetic 1x3x64x64 input.
- Final HiRef-Det checkpoint loaded and completed a CPU forward pass. A shared-calibration checkpoint was also checked if listed in `runtime_validation.json`.
- Independent and shared CSGRF with zero residual scales exactly matched concatenation at initialization.
- Both COCO evaluator paths correctly scored 120 perfect small-object detections with AP300=1, APS300=1 and AR300=1. This catches an accidental AP100 summary substitution.
- Recovered file SHA-256 manifests, packaged checkpoint SHA-256 hashes, Python AST syntax and ZIP integrity were checked.
- Text/source archives were scanned for credential patterns. The sole generic token-pattern hit was Ultralytics' documentation placeholder `your_api_key_here`, not an actual credential.

These checks establish packaging compatibility; they do not repeat full training, clean-environment installation, full-resolution/full-dataset accuracy evaluation, or all external comparison framework runs. The synthetic input check is not a measurement of paper accuracy or speed. The remote CPU environment supplied PyTorch and other existing dependencies; pycocotools 2.0.11 was installed only into the temporary check directory.
