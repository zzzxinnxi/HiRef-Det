"""Traceable inference-active profiling for a NanoDet checkpoint."""

from __future__ import annotations

import _bootstrap  # Select the bundled modified Ultralytics runtime.


import argparse
import hashlib
import json
import platform
import statistics
import sys
import time
from pathlib import Path

import torch


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


class CaptureLogger:
    def __init__(self) -> None:
        self.messages: list[str] = []

    def log(self, message: str) -> None:
        self.messages.append(message)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--imgsz", type=int, default=640)
    parser.add_argument("--device", default="0")
    parser.add_argument("--warmup", type=int, default=50)
    parser.add_argument("--timed-runs", type=int, default=200)
    parser.add_argument("--repeats", type=int, default=5)
    args = parser.parse_args()

    repo = args.repo.resolve()
    config = args.config.resolve()
    checkpoint = args.checkpoint.resolve()
    sys.path.insert(0, str(repo))

    from nanodet.model.arch import build_model
    from nanodet.util import cfg, load_config, load_model_weight
    from thop import profile as thop_profile

    load_config(cfg, str(config))
    model = build_model(cfg.model)
    logger = CaptureLogger()
    state = torch.load(checkpoint, map_location="cpu")
    load_model_weight(model, state, logger)
    if logger.messages:
        raise RuntimeError("Checkpoint/model mismatch: " + " | ".join(logger.messages[:10]))

    active_modules = [model.backbone, model.fpn, model.head]
    active_params = sum(parameter.numel() for module in active_modules for parameter in module.parameters())
    total_checkpoint_params = sum(parameter.numel() for parameter in model.parameters())

    target = torch.device(f"cuda:{args.device}" if str(args.device).isdigit() else args.device)
    model = model.to(target).eval()
    dummy = torch.zeros(1, 3, args.imgsz, args.imgsz, dtype=torch.float32, device=target)
    macs, thop_params = thop_profile(model, inputs=(dummy,), verbose=False)
    torch.backends.cudnn.benchmark = True

    latencies_ms = []
    with torch.inference_mode():
        for _ in range(args.warmup):
            model(dummy)
        torch.cuda.synchronize(target)
        for _ in range(args.repeats):
            start = time.perf_counter()
            for _ in range(args.timed_runs):
                model(dummy)
            torch.cuda.synchronize(target)
            latencies_ms.append((time.perf_counter() - start) * 1000.0 / args.timed_runs)
    latency_ms = statistics.median(latencies_ms)

    payload = {
        "model": "NanoDet-Plus-m",
        "checkpoint": {
            "path": str(checkpoint),
            "sha256": sha256(checkpoint),
            "size_bytes": checkpoint.stat().st_size,
        },
        "config": {"path": str(config), "sha256": sha256(config)},
        "metrics": {
            "inference_active_params": active_params,
            "inference_active_params_m": active_params / 1e6,
            "checkpoint_total_params_including_training_auxiliary": total_checkpoint_params,
            "thop_params": int(thop_params),
            "gmacs": float(macs) / 1e9,
            "gflops": float(macs) * 2.0 / 1e9,
            "latency_ms_median": latency_ms,
            "fps": 1000.0 / latency_ms,
            "latency_repeats_ms": latencies_ms,
        },
        "protocol": {
            "input_shape": [1, 3, args.imgsz, args.imgsz],
            "precision": "FP32",
            "forward": "backbone + FPN + inference head raw output; excludes post-processing/NMS",
            "auxiliary_training_modules_excluded_from_reported_params": True,
            "warmup_runs": args.warmup,
            "timed_runs_per_repeat": args.timed_runs,
            "repeats": args.repeats,
            "gflops_definition": "2 x THOP MACs",
        },
        "runtime": {
            "python": sys.version,
            "platform": platform.platform(),
            "torch": torch.__version__,
            "cuda": torch.version.cuda,
            "cudnn": torch.backends.cudnn.version(),
            "gpu": torch.cuda.get_device_name(target),
        },
    }
    args.output.resolve().parent.mkdir(parents=True, exist_ok=True)
    args.output.resolve().write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(payload, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
