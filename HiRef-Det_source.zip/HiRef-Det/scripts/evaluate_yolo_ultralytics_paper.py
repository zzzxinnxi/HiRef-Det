from __future__ import annotations

import argparse
import csv
import hashlib
import json
import platform
import sys
from pathlib import Path

import _bootstrap
import torch
from ultralytics import YOLO, __version__ as ultralytics_version


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description="Traceable native Ultralytics validation for one paper checkpoint")
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--imgsz", type=int, default=640)
    parser.add_argument("--batch", type=int, default=16)
    parser.add_argument("--max-det", type=int, default=300)
    parser.add_argument("--device", default="0")
    parser.add_argument("--workers", type=int, default=8)
    args = parser.parse_args()
    model_path = args.model.resolve()
    data_path = args.data.resolve()
    out = args.output_dir.resolve()
    if not model_path.is_file() or not data_path.is_file():
        raise FileNotFoundError(f"model={model_path} data={data_path}")
    out.mkdir(parents=True, exist_ok=True)

    model = YOLO(str(model_path))
    metrics = model.val(
        data=str(data_path),
        split="val",
        imgsz=args.imgsz,
        batch=args.batch,
        max_det=args.max_det,
        device=args.device,
        workers=args.workers,
        plots=False,
        save_json=False,
        verbose=False,
        project=str(out / "val_runs"),
        name=model_path.stem,
        exist_ok=False,
    )
    box = metrics.box
    class_indices = [int(index) for index in box.ap_class_index]
    all_ap = box.all_ap
    per_class = []
    for row_index, class_index in enumerate(class_indices):
        per_class.append(
            {
                "class_id": class_index,
                "class_name": model.names[class_index],
                "precision": float(box.p[row_index]),
                "recall": float(box.r[row_index]),
                "ap50": float(all_ap[row_index, 0]),
                "ap75": float(all_ap[row_index, 5]),
                "ap50_95": float(all_ap[row_index].mean()),
            }
        )
    summary = {
        "model": model_path.stem,
        "checkpoint": {"path": str(model_path), "sha256": sha256(model_path), "size_bytes": model_path.stat().st_size},
        "dataset": str(data_path),
        "protocol": {
            "split": "val",
            "imgsz": args.imgsz,
            "batch": args.batch,
            "max_det": args.max_det,
            "device": args.device,
            "workers": args.workers,
            "evaluator": "Ultralytics native model.val",
        },
        "metrics": {
            "P": float(box.mp),
            "R": float(box.mr),
            "mAP50": float(box.map50),
            "mAP50_95": float(box.map),
            "mAP75": float(getattr(box, "map75", all_ap[:, 5].mean())),
        },
        "runtime": {
            "python": sys.version,
            "platform": platform.platform(),
            "torch": torch.__version__,
            "cuda": torch.version.cuda,
            "ultralytics": ultralytics_version,
            "gpu": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
        },
        "training_metrics_are_separate": True,
    }
    (out / "native_metrics.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    with (out / "native_per_class.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(per_class[0]) if per_class else ["class_id"])
        writer.writeheader()
        writer.writerows(per_class)
    print(json.dumps(summary, indent=2, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
