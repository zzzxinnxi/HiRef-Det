import argparse
from _bootstrap import ROOT
from ultralytics import YOLO

parser = argparse.ArgumentParser()
parser.add_argument('--model', required=True, help='e.g. yolov8n.pt or yolov10n.pt')
parser.add_argument('--name',  required=True)
parser.add_argument('--seed',  type=int, default=42)
args = parser.parse_args()

m = YOLO(args.model)
m.train(
    data=f'{ROOT}/datasets/VisDrone/visdrone.yaml',
    epochs=100, imgsz=640, batch=16, workers=4,
    amp=True, cache=False, device=0,
    project=f'{ROOT}/runs/detect',
    name=args.name, seed=args.seed,
    optimizer='SGD', lr0=0.01, patience=30,
    save=True, plots=True, exist_ok=True,
)
