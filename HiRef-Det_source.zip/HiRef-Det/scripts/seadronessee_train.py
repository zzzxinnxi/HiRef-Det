#!/usr/bin/env python3
"""Train fixed-protocol SeaDronesSee ODv2 baseline and final models."""

from __future__ import annotations

import _bootstrap  # Select the bundled modified Ultralytics runtime.


import argparse
import json
import os
import sys
from pathlib import Path


ROOT = Path(os.environ.get("YOLO_RESEARCH_ROOT", str(Path(__file__).resolve().parents[1])))
sys.path.insert(0, str(ROOT))

from ultralytics import YOLO


DATA = ROOT / "datasets" / "SeaDronesSee_ODv2" / "seadronessee_odv2.yaml"
PROJECT = ROOT / "runs" / "detect_seadronessee_odv2"
PRETRAINED = ROOT / "weights/yolo11n_pretrained.pt"

MODELS = {
    "baseline": {
        "name": "yolo11n_seadronessee_odv2",
        "model": PRETRAINED,
    },
    "full": {
        "name": "yolo11n_p2_lcda_csgrf_seadronessee_odv2",
        "model": ROOT / "configs" / "yolo11n-p2-ldca-sum-csgrf-p2.yaml",
    },
}

COMMON = dict(
    data=str(DATA),
    epochs=100,
    patience=100,
    imgsz=640,
    batch=16,
    optimizer="SGD",
    lr0=0.01,
    lrf=0.01,
    momentum=0.937,
    weight_decay=0.0005,
    warmup_epochs=3.0,
    warmup_momentum=0.8,
    warmup_bias_lr=0.1,
    box=7.5,
    cls=0.5,
    dfl=1.5,
    close_mosaic=10,
    seed=42,
    deterministic=True,
    amp=True,
    device=0,
    workers=8,
    pretrained=True,
    cache=False,
    save=True,
    save_period=5,
    plots=True,
    val=True,
    project=str(PROJECT),
    exist_ok=False,
)


def build_model(key: str) -> YOLO:
    model_path = Path(MODELS[key]["model"])
    if model_path.suffix == ".pt":
        return YOLO(str(model_path))
    model = YOLO(str(model_path))
    model.load(str(PRETRAINED))
    return model


def train(key: str, smoke: bool) -> None:
    config = MODELS[key]
    kwargs = dict(COMMON)
    kwargs["name"] = f"{config['name']}_smoke" if smoke else config["name"]
    if smoke:
        kwargs.update(epochs=1, fraction=0.02, save_period=-1, plots=False)

    run_dir = PROJECT / kwargs["name"]
    if run_dir.exists():
        raise FileExistsError(f"Refusing to overwrite run: {run_dir}")
    print(json.dumps({"model_key": key, "model": str(config["model"]), **kwargs}, indent=2))
    model = build_model(key)
    model.train(**kwargs)

    best = run_dir / "weights" / "best.pt"
    if not best.exists():
        raise FileNotFoundError(best)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("smoke", "train"))
    parser.add_argument("models", nargs="+", choices=tuple(MODELS))
    args = parser.parse_args()
    for model_key in args.models:
        train(model_key, smoke=args.mode == "smoke")


if __name__ == "__main__":
    main()
