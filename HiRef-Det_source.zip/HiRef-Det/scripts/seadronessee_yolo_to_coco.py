"""Convert the prepared SeaDronesSee YOLO train/val splits to COCO JSON."""

from __future__ import annotations

import _bootstrap  # Select the bundled modified Ultralytics runtime.


import argparse
import json
from pathlib import Path

from PIL import Image


CLASS_NAMES = ["swimmer", "boat", "jetski", "life_saving_appliances", "buoy"]
IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png"}


def convert(dataset_root: Path, split: str, output: Path) -> tuple[int, int, int]:
    image_dir = dataset_root / "images" / split
    label_dir = dataset_root / "labels" / split
    image_paths = sorted(p for p in image_dir.iterdir() if p.suffix.lower() in IMAGE_SUFFIXES)
    images = []
    annotations = []
    annotation_id = 1
    duplicate_count = 0
    for image_id, image_path in enumerate(image_paths, start=1):
        with Image.open(image_path) as image:
            width, height = image.size
        images.append({"id": image_id, "file_name": image_path.name, "width": width, "height": height})
        label_path = label_dir / f"{image_path.stem}.txt"
        if not label_path.is_file():
            raise FileNotFoundError(label_path)
        seen_labels: set[tuple[int, float, float, float, float]] = set()
        for line_number, line in enumerate(label_path.read_text(encoding="ascii").splitlines(), start=1):
            if not line.strip():
                continue
            fields = line.split()
            if len(fields) != 5:
                raise ValueError(f"Invalid label at {label_path}:{line_number}")
            class_id = int(fields[0])
            if not 0 <= class_id < len(CLASS_NAMES):
                raise ValueError(f"Invalid class at {label_path}:{line_number}")
            cx, cy, bw, bh = map(float, fields[1:])
            normalized_label = (class_id, cx, cy, bw, bh)
            if normalized_label in seen_labels:
                duplicate_count += 1
                continue
            seen_labels.add(normalized_label)
            x1 = max(0.0, (cx - bw / 2.0) * width)
            y1 = max(0.0, (cy - bh / 2.0) * height)
            x2 = min(float(width), (cx + bw / 2.0) * width)
            y2 = min(float(height), (cy + bh / 2.0) * height)
            box_width, box_height = x2 - x1, y2 - y1
            if box_width <= 0 or box_height <= 0:
                raise ValueError(f"Degenerate box at {label_path}:{line_number}")
            annotations.append(
                {
                    "id": annotation_id,
                    "image_id": image_id,
                    "category_id": class_id + 1,
                    "bbox": [x1, y1, box_width, box_height],
                    "area": box_width * box_height,
                    "iscrowd": 0,
                }
            )
            annotation_id += 1
    payload = {
        "info": {"description": "SeaDronesSee ODv2 prepared split"},
        "licenses": [],
        "images": images,
        "annotations": annotations,
        "categories": [
            {"id": index + 1, "name": name, "supercategory": "object"}
            for index, name in enumerate(CLASS_NAMES)
        ],
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, ensure_ascii=True), encoding="ascii")
    return len(images), len(annotations), duplicate_count


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset-root", type=Path, required=True)
    args = parser.parse_args()
    for split in ("train", "val"):
        output = args.dataset_root / "coco_annotations" / f"instances_{split}.json"
        images, boxes, duplicates = convert(args.dataset_root, split, output)
        print(
            f"{split}: images={images} annotations={boxes} "
            f"duplicates_removed={duplicates} output={output}"
        )


if __name__ == "__main__":
    main()
