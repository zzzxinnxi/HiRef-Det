#!/usr/bin/env python3
"""Prepare SeaDronesSee ODv2 COCO annotations for Ultralytics YOLO."""

from __future__ import annotations

import _bootstrap  # Select the bundled modified Ultralytics runtime.


import argparse
import json
import shutil
import zipfile
from collections import defaultdict
from pathlib import Path


CLASS_NAMES = ["swimmer", "boat", "jetski", "life_saving_appliances", "buoy"]
CATEGORY_TO_CLASS = {category_id: category_id - 1 for category_id in range(1, 6)}


def archive_image_names(archive: zipfile.ZipFile, split: str) -> set[str]:
    prefix = f"{split}/"
    return {
        Path(name).name
        for name in archive.namelist()
        if name.startswith(prefix) and not name.endswith("/")
    }


def extract_images(images_zip: Path, dataset_root: Path) -> None:
    images_root = dataset_root / "images"
    images_root.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(images_zip) as archive:
        bad_member = archive.testzip()
        if bad_member:
            raise RuntimeError(f"Corrupt image member: {bad_member}")
        for split in ("train", "val"):
            expected = archive_image_names(archive, split)
            split_dir = images_root / split
            existing = {item.name for item in split_dir.glob("*.jpg")} if split_dir.exists() else set()
            if existing == expected:
                print(f"{split}: {len(existing)} images already extracted")
                continue
            split_dir.mkdir(parents=True, exist_ok=True)
            for member in archive.infolist():
                if member.filename.startswith(f"{split}/") and not member.is_dir():
                    destination = split_dir / Path(member.filename).name
                    with archive.open(member) as source, destination.open("wb") as target:
                        shutil.copyfileobj(source, target, length=1024 * 1024)


def convert_split(annotations_zip: Path, dataset_root: Path, split: str) -> dict[str, int]:
    member = f"annotations/instances_{split}.json"
    with zipfile.ZipFile(annotations_zip) as archive, archive.open(member) as stream:
        coco = json.load(stream)

    categories = {item["id"]: item["name"] for item in coco["categories"]}
    expected_categories = {0: "ignored", **{index + 1: name for index, name in enumerate(CLASS_NAMES)}}
    if categories != expected_categories:
        raise ValueError(f"Unexpected categories: {categories}")

    images = {item["id"]: item for item in coco["images"]}
    labels_by_image: dict[int, list[str]] = defaultdict(list)
    skipped_ignored = 0
    clipped_boxes = 0

    for annotation in coco["annotations"]:
        category_id = annotation["category_id"]
        if category_id == 0:
            skipped_ignored += 1
            continue
        if category_id not in CATEGORY_TO_CLASS:
            raise ValueError(f"Unknown category id: {category_id}")
        image = images[annotation["image_id"]]
        width, height = image["width"], image["height"]
        x, y, box_width, box_height = annotation["bbox"]
        x1 = max(0.0, min(float(width), float(x)))
        y1 = max(0.0, min(float(height), float(y)))
        x2 = max(0.0, min(float(width), float(x + box_width)))
        y2 = max(0.0, min(float(height), float(y + box_height)))
        clipped_boxes += (x1, y1, x2, y2) != (x, y, x + box_width, y + box_height)
        if x2 <= x1 or y2 <= y1:
            raise ValueError(f"Degenerate box after clipping: {annotation}")
        center_x = ((x1 + x2) / 2.0) / width
        center_y = ((y1 + y2) / 2.0) / height
        normalized_width = (x2 - x1) / width
        normalized_height = (y2 - y1) / height
        class_id = CATEGORY_TO_CLASS[category_id]
        labels_by_image[annotation["image_id"]].append(
            f"{class_id} {center_x:.8f} {center_y:.8f} {normalized_width:.8f} {normalized_height:.8f}"
        )

    image_dir = dataset_root / "images" / split
    label_dir = dataset_root / "labels" / split
    label_dir.mkdir(parents=True, exist_ok=True)
    expected_images = {Path(item["file_name"]).name for item in images.values()}
    actual_images = {item.name for item in image_dir.glob("*.jpg")}
    if expected_images != actual_images:
        raise RuntimeError(
            f"{split} image mismatch: missing={len(expected_images - actual_images)}, "
            f"extra={len(actual_images - expected_images)}"
        )

    label_count = 0
    for image_id, image in images.items():
        label_path = label_dir / f"{Path(image['file_name']).stem}.txt"
        lines = labels_by_image.get(image_id, [])
        label_path.write_text("\n".join(lines) + ("\n" if lines else ""), encoding="ascii")
        label_count += len(lines)

    expected_annotations = sum(item["category_id"] != 0 for item in coco["annotations"])
    if label_count != expected_annotations:
        raise RuntimeError(f"{split} label count mismatch: {label_count} != {expected_annotations}")
    return {
        "images": len(images),
        "labels": label_count,
        "empty_images": len(images) - len(labels_by_image),
        "skipped_ignored": skipped_ignored,
        "clipped_boxes": clipped_boxes,
    }


def write_yaml(dataset_root: Path) -> Path:
    yaml_path = dataset_root / "seadronessee_odv2.yaml"
    names = "\n".join(f"  {index}: {name}" for index, name in enumerate(CLASS_NAMES))
    yaml_path.write_text(
        f"path: {dataset_root}\ntrain: images/train\nval: images/val\nnames:\n{names}\n",
        encoding="ascii",
    )
    return yaml_path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--images-zip", type=Path, required=True)
    parser.add_argument("--annotations-zip", type=Path, required=True)
    parser.add_argument("--dataset-root", type=Path, required=True)
    args = parser.parse_args()
    args.dataset_root = args.dataset_root.resolve()

    args.dataset_root.mkdir(parents=True, exist_ok=True)
    extract_images(args.images_zip, args.dataset_root)
    summary = {
        split: convert_split(args.annotations_zip, args.dataset_root, split)
        for split in ("train", "val")
    }
    yaml_path = write_yaml(args.dataset_root)
    (args.dataset_root / "conversion_summary.json").write_text(
        json.dumps(summary, indent=2), encoding="ascii"
    )
    print(json.dumps(summary, indent=2))
    print(f"data_yaml={yaml_path}")


if __name__ == "__main__":
    main()
