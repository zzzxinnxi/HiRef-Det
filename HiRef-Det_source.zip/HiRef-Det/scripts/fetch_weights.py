"""Place verified published checkpoints under weights/. Use --all for ablations."""
import argparse,hashlib,json,shutil,urllib.request
from pathlib import Path
root=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--all',action='store_true');a=p.parse_args()
entries=json.loads((root/'weights/manifest.json').read_text(encoding='utf8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for e in entries:
    if not a.all and e['role']!='initial release':continue
    target=root/e['file'];target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists() and sha(target)==e['sha256']:continue
    legacy=root/target.name
    if legacy.exists() and sha(legacy)==e['sha256']:shutil.copy2(legacy,target)
    else:
        remote=target.name if e['role']=='initial release' else e['file']
        urllib.request.urlretrieve('https://raw.githubusercontent.com/zzzxinnxi/HiRef-Det/main/'+remote,target)
    if sha(target)!=e['sha256']:raise RuntimeError('Checksum mismatch: '+target.name)
    print('Verified',target.name)
