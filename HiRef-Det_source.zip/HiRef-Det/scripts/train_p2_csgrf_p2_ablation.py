
import _bootstrap  # Select the bundled modified Ultralytics runtime.

"""Train the P2+CSGRF ablation without LDCA."""

import os
import sys
from pathlib import Path

PROJECT_ROOT = Path(os.environ.get("YOLO_RESEARCH_ROOT", Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(PROJECT_ROOT))

from ultralytics import YOLO


def main():
    model = YOLO(str(PROJECT_ROOT / "configs/yolo11n-p2-csgrf-p2-ablation.yaml"))
    model.load(str(PROJECT_ROOT / "weights/yolo11n_pretrained.pt"))
    model.train(
        data=str(PROJECT_ROOT / "datasets/VisDrone/visdrone.yaml"),
        imgsz=640,
        device=0,
        amp=True,
        cache=False,
        project=str(PROJECT_ROOT / "runs/detect"),
        optimizer="SGD",
        lr0=0.01,
        save=True,
        plots=True,
        epochs=100,
        batch=16,
        workers=8,
        seed=42,
        name="yolo11n_p2_csgrf_p2_ablation",
        patience=30,
        exist_ok=False,
    )


if __name__ == "__main__":
    main()

