"""
VisDrone2019-DET 标注格式转 YOLO 格式

VisDrone 原始格式 (annotations/*.txt 每行):
    bbox_left, bbox_top, bbox_width, bbox_height, score, category, truncation, occlusion

类别:
    0=ignored, 1=pedestrian, 2=people, 3=bicycle, 4=car, 5=van,
    6=truck, 7=tricycle, 8=awning-tricycle, 9=bus, 10=motor, 11=others

YOLO 格式 (labels/*.txt 每行):
    class cx cy w h    (归一化到[0,1])

转换规则:
    - 丢弃 score=0 (ignored regions) 和 category=0/11 (ignored/others)
    - 类别 1-10 重映射到 0-9
"""

from pathlib import Path
from PIL import Image
from tqdm import tqdm


def convert_split(split_dir: Path) -> None:
    """转换单个数据集划分(train/val/test-dev)。"""
    ann_dir = split_dir / "annotations"
    img_dir = split_dir / "images"
    lbl_dir = split_dir / "labels"
    lbl_dir.mkdir(exist_ok=True)

    if not ann_dir.exists():
        print(f"[skip] {split_dir} 缺少 annotations 目录")
        return

    txt_files = sorted(ann_dir.glob("*.txt"))
    if not txt_files:
        print(f"[skip] {ann_dir} 没有标注文件")
        return

    print(f"[处理] {split_dir.name}: {len(txt_files)} 个标注文件")
    n_kept_total, n_dropped_total = 0, 0

    for ann_path in tqdm(txt_files, desc=split_dir.name):
        img_path = img_dir / (ann_path.stem + ".jpg")
        if not img_path.exists():
            continue

        with Image.open(img_path) as im:
            W, H = im.size

        yolo_lines = []
        with open(ann_path, "r", encoding="utf-8") as f:
            for line in f:
                parts = line.strip().rstrip(",").split(",")
                if len(parts) < 6:
                    continue
                x, y, w, h = map(int, parts[:4])
                score = int(parts[4])
                cls = int(parts[5])

                if score == 0 or cls in (0, 11):
                    n_dropped_total += 1
                    continue
                if w <= 0 or h <= 0:
                    n_dropped_total += 1
                    continue

                new_cls = cls - 1
                cx = (x + w / 2) / W
                cy = (y + h / 2) / H
                bw = w / W
                bh = h / H
                yolo_lines.append(f"{new_cls} {cx:.6f} {cy:.6f} {bw:.6f} {bh:.6f}")
                n_kept_total += 1

        out_path = lbl_dir / ann_path.name
        out_path.write_text("\n".join(yolo_lines) + ("\n" if yolo_lines else ""), encoding="utf-8")

    print(f"  保留 {n_kept_total} 个目标，丢弃 {n_dropped_total} 个")


def main() -> None:
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset-root", type=Path, default=Path(__file__).resolve().parents[1] / "datasets/VisDrone")
    root = parser.parse_args().dataset_root
    splits = [
        "VisDrone2019-DET-train",
        "VisDrone2019-DET-val",
        "VisDrone2019-DET-test-dev",
    ]
    for s in splits:
        d = root / s
        if d.exists():
            convert_split(d)
        else:
            print(f"[未找到] {d}（请确认数据集已解压）")


if __name__ == "__main__":
    main()
