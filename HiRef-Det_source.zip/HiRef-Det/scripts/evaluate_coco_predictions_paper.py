"""Recompute traceable COCO metrics from an existing prediction JSON."""

from __future__ import annotations

import argparse
import hashlib
import json
from contextlib import redirect_stdout
from pathlib import Path

import numpy as np
from pycocotools.coco import COCO
from pycocotools.cocoeval import COCOeval


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--gt-json", type=Path, required=True)
    parser.add_argument("--predictions", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--log", type=Path, required=True)
    parser.add_argument("--max-det", type=int, default=300)
    args = parser.parse_args()

    gt_path = args.gt_json.resolve()
    prediction_path = args.predictions.resolve()
    output_path = args.output.resolve()
    log_path = args.log.resolve()
    coco_gt = COCO(str(gt_path))
    coco_dt = coco_gt.loadRes(str(prediction_path))
    evaluator = COCOeval(coco_gt, coco_dt, "bbox")
    evaluator.params.maxDets = [1, 10, args.max_det]
    evaluator.params.imgIds = sorted(coco_gt.getImgIds())
    evaluator.params.catIds = sorted(coco_gt.getCatIds())
    evaluator.evaluate()
    evaluator.accumulate()
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("w", encoding="utf-8") as handle, redirect_stdout(handle):
        evaluator.summarize()

    precision = evaluator.eval["precision"]
    recall = evaluator.eval["recall"]
    max_det_index = evaluator.params.maxDets.index(args.max_det)
    area_index = {label: index for index, label in enumerate(evaluator.params.areaRngLbl)}

    def valid_mean(values: np.ndarray) -> float:
        valid = values[values > -1]
        return float(valid.mean()) if valid.size else -1.0

    def ap(iou_index: int | None, area_label: str) -> float:
        values = precision[:, :, :, area_index[area_label], max_det_index]
        if iou_index is not None:
            values = values[iou_index : iou_index + 1]
        return valid_mean(values)

    def ar(area_label: str, max_dets: int) -> float:
        index = evaluator.params.maxDets.index(max_dets)
        return valid_mean(recall[:, :, area_index[area_label], index])

    gt = json.loads(gt_path.read_text(encoding="utf-8"))
    predictions = json.loads(prediction_path.read_text(encoding="utf-8"))
    payload = {
        "ground_truth": {
            "path": str(gt_path),
            "sha256": sha256(gt_path),
            "images": len(gt["images"]),
            "annotations": len(gt["annotations"]),
            "categories": len(gt["categories"]),
        },
        "predictions": {
            "path": str(prediction_path),
            "sha256": sha256(prediction_path),
            "detections": len(predictions),
        },
        "protocol": {
            "max_dets": [1, 10, args.max_det],
            "area_ranges_original_pixels": {
                "small": "area < 32^2",
                "medium": "32^2 <= area < 96^2",
                "large": "area >= 96^2",
            },
        },
        "metrics": {
            "ap": ap(None, "all"),
            "ap50": ap(0, "all"),
            "ap75": ap(5, "all"),
            "aps": ap(None, "small"),
            "apm": ap(None, "medium"),
            "apl": ap(None, "large"),
            "ar1": ar("all", 1),
            "ar10": ar("all", 10),
            "ar300": ar("all", args.max_det),
            "ars": ar("small", args.max_det),
            "arm": ar("medium", args.max_det),
            "arl": ar("large", args.max_det),
        },
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(payload, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
