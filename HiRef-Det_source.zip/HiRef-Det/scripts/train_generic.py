import os
import sys
import argparse
from pathlib import Path

PROJECT_ROOT = Path(os.environ.get("YOLO_RESEARCH_ROOT", Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(PROJECT_ROOT))

import _bootstrap
from ultralytics import YOLO


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--config", required=True, help="model yaml under configs/ or abs path")
    p.add_argument("--name", required=True, help="run name under runs/detect/")
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--epochs", type=int, default=100)
    p.add_argument("--batch", type=int, default=16)
    args = p.parse_args()

    cfg = args.config
    if not os.path.isabs(cfg):
        cfg = str(PROJECT_ROOT / "configs" / cfg)

    model = YOLO(cfg)
    model.load(str(PROJECT_ROOT / "weights/yolo11n_pretrained.pt"))

    model.train(
        data=str(PROJECT_ROOT / "datasets/VisDrone/visdrone.yaml"),
        imgsz=640, device=0, amp=True, cache=False,
        project=str(PROJECT_ROOT / "runs/detect"),
        optimizer="SGD", lr0=0.01, save=True, plots=True,
        epochs=args.epochs, batch=args.batch, workers=8,
        seed=args.seed, name=args.name, patience=30, exist_ok=True,
    )


if __name__ == "__main__":
    main()
