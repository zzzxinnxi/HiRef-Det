"""Predict with a released checkpoint using the bundled modified runtime."""
import argparse
import _bootstrap
from ultralytics import YOLO

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", default="weights/hiref_det_visdrone.pt")
    parser.add_argument("--source", required=True)
    parser.add_argument("--device", default="0")
    parser.add_argument("--conf", type=float, default=0.25)
    args = parser.parse_args()
    YOLO(args.model).predict(source=args.source, imgsz=640, device=args.device,
                             conf=args.conf, save=True)

if __name__ == "__main__":
    main()
