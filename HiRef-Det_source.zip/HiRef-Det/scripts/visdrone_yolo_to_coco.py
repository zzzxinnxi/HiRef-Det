"""Convert the exact VisDrone YOLO train/val labels used in this project to COCO JSON."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from PIL import Image


CLASS_NAMES = [
    "pedestrian",
    "people",
    "bicycle",
    "car",
    "van",
    "truck",
    "tricycle",
    "awning-tricycle",
    "bus",
    "motor",
]
IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png", ".bmp"}


def convert_split(split_dir: Path, output_path: Path) -> tuple[int, int]:
    image_dir = split_dir / "images"
    label_dir = split_dir / "labels"
    image_paths = sorted(p for p in image_dir.iterdir() if p.suffix.lower() in IMAGE_SUFFIXES)
    if not image_paths:
        raise RuntimeError(f"No images found in {image_dir}")

    images: list[dict] = []
    annotations: list[dict] = []
    annotation_id = 1

    for image_id, image_path in enumerate(image_paths, start=1):
        with Image.open(image_path) as image:
            width, height = image.size
        images.append(
            {
                "id": image_id,
                "file_name": image_path.name,
                "width": width,
                "height": height,
            }
        )

        label_path = label_dir / f"{image_path.stem}.txt"
        if not label_path.is_file():
            raise FileNotFoundError(f"Missing label file: {label_path}")

        for line_number, line in enumerate(label_path.read_text(encoding="utf-8").splitlines(), start=1):
            if not line.strip():
                continue
            fields = line.split()
            if len(fields) < 5:
                raise ValueError(f"Invalid label at {label_path}:{line_number}: {line}")
            class_id = int(float(fields[0]))
            if not 0 <= class_id < len(CLASS_NAMES):
                raise ValueError(f"Invalid class {class_id} at {label_path}:{line_number}")

            x_center, y_center, box_width, box_height = map(float, fields[1:5])
            x = max(0.0, (x_center - box_width / 2.0) * width)
            y = max(0.0, (y_center - box_height / 2.0) * height)
            x2 = min(float(width), (x_center + box_width / 2.0) * width)
            y2 = min(float(height), (y_center + box_height / 2.0) * height)
            clipped_width = x2 - x
            clipped_height = y2 - y
            if clipped_width <= 0 or clipped_height <= 0:
                raise ValueError(f"Degenerate box at {label_path}:{line_number}")

            annotations.append(
                {
                    "id": annotation_id,
                    "image_id": image_id,
                    # RT-DETR custom datasets expect contiguous zero-based labels.
                    "category_id": class_id,
                    "bbox": [x, y, clipped_width, clipped_height],
                    "area": clipped_width * clipped_height,
                    "iscrowd": 0,
                }
            )
            annotation_id += 1

    payload = {
        "info": {"description": "VisDrone labels converted from the project's YOLO split"},
        "licenses": [],
        "images": images,
        "annotations": annotations,
        "categories": [{"id": i, "name": name, "supercategory": "object"} for i, name in enumerate(CLASS_NAMES)],
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(payload, ensure_ascii=True), encoding="utf-8")
    return len(images), len(annotations)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset-root", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    args = parser.parse_args()

    splits = {
        "train": "VisDrone2019-DET-train",
        "val": "VisDrone2019-DET-val",
    }
    for output_name, split_name in splits.items():
        image_count, annotation_count = convert_split(
            args.dataset_root / split_name,
            args.output_dir / f"instances_{output_name}.json",
        )
        print(f"{output_name}: images={image_count}, annotations={annotation_count}")


if __name__ == "__main__":
    main()
