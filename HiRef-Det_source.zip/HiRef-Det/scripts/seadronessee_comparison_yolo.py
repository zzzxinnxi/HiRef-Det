"""Train one YOLO-family comparison on SeaDronesSee ODv2."""

from __future__ import annotations

import _bootstrap  # Select the bundled modified Ultralytics runtime.


import argparse
import os
import sys
from pathlib import Path


ROOT = Path(str(Path(__file__).resolve().parents[1]))
DATA = ROOT / "datasets/SeaDronesSee_ODv2/seadronessee_odv2.yaml"
PROJECT = ROOT / "runs/detect_seadronessee_comparison"
MODELS = {
    "yolov8n": (None, ROOT / "yolov8n.pt"),
    "yolov10n": (None, ROOT / "yolov10n.pt"),
    "yolov12n": (ROOT / "external/yolov12", ROOT / "external/yolov12/yolov12n.pt"),
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("model", choices=tuple(MODELS))
    parser.add_argument("--smoke", action="store_true")
    args = parser.parse_args()

    repo, weights = MODELS[args.model]
    if not DATA.is_file():
        raise FileNotFoundError(DATA)
    if repo is not None and not (repo / "ultralytics").is_dir():
        raise FileNotFoundError(f"Missing source package: {repo / 'ultralytics'}")
    if not weights.is_file():
        raise FileNotFoundError(weights)

    if repo is not None:
        sys.path.insert(0, str(repo))
        os.chdir(repo)
    from ultralytics import YOLO

    name = f"{args.model}_seadronessee_odv2"
    if args.smoke:
        name += "_smoke"
    run_dir = PROJECT / name
    if run_dir.exists():
        raise FileExistsError(f"Refusing to overwrite {run_dir}")

    model = YOLO(str(weights))
    print(f"model={args.model} params={sum(p.numel() for p in model.model.parameters())}")
    model.train(
        data=str(DATA),
        epochs=1 if args.smoke else 100,
        patience=1000,
        imgsz=640,
        batch=16,
        optimizer="SGD",
        lr0=0.01,
        lrf=0.01,
        momentum=0.937,
        weight_decay=0.0005,
        warmup_epochs=3.0,
        warmup_momentum=0.8,
        warmup_bias_lr=0.1,
        box=7.5,
        cls=0.5,
        dfl=1.5,
        close_mosaic=10,
        seed=42,
        deterministic=True,
        amp=True,
        device=0,
        workers=4 if args.smoke else 8,
        pretrained=True,
        cache=False,
        save=not args.smoke,
        plots=not args.smoke,
        val=True,
        max_det=300,
        fraction=0.02 if args.smoke else 1.0,
        project=str(PROJECT),
        name=name,
        exist_ok=False,
    )


if __name__ == "__main__":
    main()
