"""Train the final YOLO11n-P2-LCDA-CSGRF model with one fixed seed."""

from __future__ import annotations

import _bootstrap  # Select the bundled modified Ultralytics runtime.


import argparse
import os
import sys
from pathlib import Path

import torch


PROJECT_ROOT = Path(
    os.environ.get("YOLO_RESEARCH_ROOT", Path(__file__).resolve().parents[1])
)
sys.path.insert(0, str(PROJECT_ROOT))

from ultralytics import YOLO


def build_model() -> YOLO:
    model = YOLO(
        str(PROJECT_ROOT / "configs/yolo11n-p2-ldca-sum-csgrf-p2.yaml")
    )
    model.load(str(PROJECT_ROOT / "weights/yolo11n_pretrained.pt"))
    return model


def check_model() -> None:
    model = build_model()
    model.model.to("cuda").eval()
    with torch.no_grad():
        output = model.model(torch.zeros(1, 3, 640, 640, device="cuda"))
    output_type = type(output).__name__
    print(f"CHECK_OK output_type={output_type}", flush=True)


def train(seed: int) -> None:
    model = build_model()
    model.train(
        data=str(PROJECT_ROOT / "datasets/VisDrone/visdrone.yaml"),
        imgsz=640,
        epochs=100,
        batch=16,
        device=0,
        workers=8,
        optimizer="SGD",
        lr0=0.01,
        amp=True,
        cache=False,
        deterministic=True,
        seed=seed,
        patience=1000,
        max_det=300,
        save=True,
        plots=True,
        project=str(PROJECT_ROOT / "runs/detect"),
        name=f"yolo11n_p2_lcda_csgrf_visdrone_seed{seed}",
        exist_ok=False,
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed", type=int, choices=(0, 1), required=False)
    parser.add_argument("--check-only", action="store_true")
    args = parser.parse_args()

    if args.check_only:
        check_model()
        return
    if args.seed is None:
        parser.error("--seed is required unless --check-only is used")
    train(args.seed)


if __name__ == "__main__":
    main()
