from __future__ import annotations

import _bootstrap  # Select the bundled modified Ultralytics runtime.


import hashlib
import json
import os
import platform
import subprocess
import sys
from pathlib import Path

import torch
import yaml

ROOT = Path(os.environ.get("YOLO_RESEARCH_ROOT", str(Path(__file__).resolve().parents[1])))
sys.path.insert(0, str(ROOT))
from ultralytics import YOLO, __version__ as ultralytics_version  # noqa: E402


TARGET = ROOT / "runs/detect/baseline_yolo11n_b16_seed42_canonical"
PRETRAINED = ROOT / "weights/yolo11n_pretrained.pt"
OUT = ROOT / "paper_metrics/canonical_baseline_b16_seed42"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def environment() -> dict:
    try:
        gpu = subprocess.run(
            ["nvidia-smi", "--query-gpu=name,driver_version,memory.total", "--format=csv,noheader"],
            check=True,
            capture_output=True,
            text=True,
        ).stdout.strip()
    except Exception as exc:  # pragma: no cover
        gpu = f"unavailable: {exc}"
    return {
        "python": sys.version,
        "platform": platform.platform(),
        "torch": torch.__version__,
        "cuda": torch.version.cuda,
        "cudnn": torch.backends.cudnn.version(),
        "ultralytics": ultralytics_version,
        "gpu": gpu,
        "pretrained": {"path": str(PRETRAINED), "sha256": sha256(PRETRAINED)},
    }


def main() -> None:
    if TARGET.exists():
        raise RuntimeError(f"Refusing to overwrite existing run: {TARGET}")
    if not PRETRAINED.is_file():
        raise FileNotFoundError(PRETRAINED)
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "environment.json").write_text(json.dumps(environment(), indent=2), encoding="utf-8")

    model = YOLO(str(PRETRAINED))
    custom = sorted(
        {
            type(module).__name__
            for module in model.model.modules()
            if type(module).__name__ in {"CSGRF", "LDCA", "LCDA"}
        }
    )
    if custom:
        raise RuntimeError(f"Original YOLOv11n unexpectedly contains custom modules: {custom}")
    initial_identity = {
        "model_source": str(PRETRAINED),
        "pretrained_sha256": sha256(PRETRAINED),
        "architecture": "original Ultralytics YOLOv11n; no P2, CSGRF, LCDA, or custom modules",
        "yaml": model.model.yaml,
        "names": model.names,
    }

    model.train(
        data=str(ROOT / "datasets/VisDrone/visdrone.yaml"),
        epochs=100,
        batch=16,
        imgsz=640,
        optimizer="SGD",
        lr0=0.01,
        pretrained=str(PRETRAINED),
        project=str(ROOT / "runs/detect"),
        name="baseline_yolo11n_b16_seed42_canonical",
        exist_ok=False,
        save=True,
        save_period=-1,
        plots=True,
        device=0,
        workers=8,
        seed=42,
        deterministic=True,
        patience=30,
        amp=True,
        cache=False,
        cos_lr=False,
        close_mosaic=10,
        max_det=300,
        fraction=1.0,
        val=True,
        split="val",
        iou=0.7,
        verbose=True,
    )
    if not TARGET.is_dir():
        raise RuntimeError(f"Training returned without expected run directory: {TARGET}")
    (TARGET / "model_identity.yaml").write_text(
        yaml.safe_dump(initial_identity, sort_keys=False, allow_unicode=True), encoding="utf-8"
    )
    (TARGET / "environment.json").write_text(
        (OUT / "environment.json").read_text(encoding="utf-8"), encoding="utf-8"
    )
    print(f"TRAINING_COMPLETE run={TARGET}", flush=True)


if __name__ == "__main__":
    main()
